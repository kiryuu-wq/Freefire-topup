document.addEventListener('DOMContentLoaded', () => {
    const diamondPrices = {
        "10 DM": 2000,
        "15 DM": 3000,
        "20 DM": 3500,
        "30 DM": 5000,
        "50 DM": 7000,
        "70 DM": 9000,
        "80 DM": 11500,
        "90 DM": 14000,
        "100 DM": 14500,
        "140 DM": 18500,
        "150 DM": 20000,
        "200 DM": 28000,
        "250 DM": 33000,
        "280 DM": 36000,
        "300 DM": 39500,
        "355 DM": 45000,
        "375 DM": 48000,
        "400 DM": 52500,
        "425 DM": 54000,
        "500 DM": 63500,
        "520 DM": 66500,
        "565 DM": 69500,
        "600 DM": 76000,
        "635 DM": 80500,
        "720 DM": 90500,
        "770 DM": 94500,
        "800 DM": 97500,
        "850+10 DM": 107000,
        "913 DM": 113500,
        "1000 DM": 123000,
        "1300 DM": 159000,
        "1580 DM": 193000,
        "2000 DM": 243000,
        "2280 DM": 273500,
        "4000 DM": 511000,
        "7290 DM": 912000
    };

    const diamondListContainer = document.querySelector('.diamond-list');
    const selectItemButtons = document.querySelectorAll('.select-item');
    const selectPaymentButtons = document.querySelectorAll('.select-payment');
    const copyButtons = document.querySelectorAll('.copy-button');
    const sendWhatsappButton = document.getElementById('send-whatsapp');
    const playerIdInput = document.getElementById('player-id');

    let selectedItem = null;
    let selectedPaymentMethod = null;
    let selectedPrice = 0;

    // Fungsi untuk memformat angka menjadi format Rupiah
    const formatRupiah = (angka) => {
        const rupiah = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(angka);
        return rupiah;
    };

    // Render Diamond List
    for (const [nominal, price] of Object.entries(diamondPrices)) {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('item');
        itemDiv.dataset.name = nominal;
        itemDiv.dataset.price = price;
        itemDiv.innerHTML = `
            <h3>${nominal}</h3>
            <p>Harga: ${formatRupiah(price)}</p>
            <button class="select-item">Pilih</button>
        `;
        diamondListContainer.appendChild(itemDiv);
    }

    // Event Listener untuk tombol "Pilih" pada item
    document.querySelectorAll('.select-item').forEach(button => {
        button.addEventListener('click', (event) => {
            // Hapus kelas 'selected' dari semua item lain
            document.querySelectorAll('.item').forEach(item => {
                item.classList.remove('selected');
            });

            const itemDiv = event.target.closest('.item');
            itemDiv.classList.add('selected'); // Tambahkan kelas 'selected' ke item yang dipilih

            selectedItem = itemDiv.dataset.name;
            selectedPrice = parseInt(itemDiv.dataset.price);
            updateOrderSummary();
        });
    });

    // Event Listener untuk tombol "Pilih" pada metode pembayaran
    selectPaymentButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            // Hapus kelas 'selected' dari semua metode pembayaran
            document.querySelectorAll('.payment-method').forEach(method => {
                method.classList.remove('selected');
            });

            const paymentMethodDiv = event.target.closest('.payment-method');
            paymentMethodDiv.classList.add('selected');

            selectedPaymentMethod = event.target.dataset.method;
            updateOrderSummary();
        });
    });

    // Event Listener untuk tombol "Salin Nomor"
    copyButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const targetId = event.target.dataset.target;
            const textToCopy = document.getElementById(targetId).innerText;
            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    alert(`Nomor ${targetId === 'dana-number' ? 'DANA' : 'Rekening'} berhasil disalin: ${textToCopy}`);
                })
                .catch(err => {
                    console.error('Gagal menyalin: ', err);
                });
        });
    });

    // Fungsi untuk update detail pesanan
    const updateOrderSummary = () => {
        const orderNominal = document.getElementById('order-nominal');
        const orderItem = document.getElementById('order-item');
        const orderTime = document.getElementById('order-time');

        if (selectedItem) {
            orderItem.textContent = selectedItem;
            orderNominal.textContent = formatRupiah(selectedPrice);
        } else {
            orderItem.textContent = '-';
            orderNominal.textContent = '-';
        }

        orderTime.textContent = new Date().toLocaleString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    };

    // Event Listener untuk tombol kirim WhatsApp
    sendWhatsappButton.addEventListener('click', () => {
        const playerId = playerIdInput.value.trim();
        if (!playerId) {
            alert('Mohon masukkan ID Pemain Free Fire Anda.');
            return;
        }

        if (!selectedItem || selectedPrice === 0) {
            alert('Mohon pilih nominal diamond atau paket terlebih dahulu.');
            return;
        }

        if (!selectedPaymentMethod) {
            alert('Mohon pilih metode pembayaran.');
            return;
        }

        const currentTime = new Date().toLocaleString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });

        const whatsappMessage = `
Detail Pesanan:
ID Pemain: ${playerId}
Nominal: ${selectedItem}
Barang: ${selectedItem} (Harga: ${formatRupiah(selectedPrice)})
Metode Pembayaran: ${selectedPaymentMethod}
Waktu Transaksi: ${currentTime}

Mohon segera dilakukan, terima kasih!
        `.trim();

        // Ganti dengan nomor WhatsApp Anda
        const whatsappNumber = '6281234567890'; // Contoh: Ganti dengan nomor WhatsApp Anda, tanpa '+' atau '0' di depan

        const whatsappURL = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;
        window.open(whatsappURL, '_blank');
    });

    // Inisialisasi ringkasan pesanan saat halaman dimuat
    updateOrderSummary();
});